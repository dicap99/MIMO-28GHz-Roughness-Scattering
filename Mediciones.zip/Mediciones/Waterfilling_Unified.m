% Waterfilling_Unified.m
% Unificación de los modelos de simulación Waterfilling.m y Waterfilling2.m
% Genera gráficas ÚNICAMENTE de la asignación de potencia.

clc; clear; close all;

%% 1. PARÁMETROS GLOBALES
f = 28e9; c = 3e8; lambda = c / f; k_wave = 2 * pi / lambda;
N = 4;
P_t_dBm = 9; Pt_W = 10^((P_t_dBm - 30)/10);
NF = -38.7; Pn_W = 10^((NF - 30)/10);
XPD_dB = 30;

theta_i_list = [30, 45, 60];
num_angulos = length(theta_i_list);

% Construcción empírica del canal Línea de Vista (LoS)
m = (0:N-1)';
gen_A = @(th) (exp(-1j * pi * cos(th) * m)) * (exp(-1j * pi * cos(th) * m))';
dBm_vv = -2.63; dBm_vh = -32.03; dBm_hv = -20.61; dBm_hh = -2.09;
Psi_Los = sqrt((10.^([dBm_vv, dBm_vh; dBm_hv, dBm_hh] / 10)) / 1000);
A_LoS = gen_A(deg2rad(90));
H_LoS = kron(Psi_Los, A_LoS);

%% ========================================================================
%% MODELO 1 (Basado en Waterfilling.m)
%% ========================================================================
G_sys = 53.25;
eta_0 = 377; eta_mat = 153.9 + 1.92i; theta_t = 0;
sigma_vec1 = linspace(0, 10e-3, 100);

P_alloc_M1 = zeros(4, num_angulos, length(sigma_vec1));

for i = 1:num_angulos
    ti_deg = theta_i_list(i);
    ti_rad = deg2rad(ti_deg);
    alpha_deg = 90 - ti_deg;
    d_s = 2 * (0.5 / cosd(alpha_deg));
    FSPL_s_dB = 20 * log10((4 * pi * d_s) / lambda);

    Gamma_v = (eta_mat * cos(theta_t) - eta_0 * cos(ti_rad)) / (eta_mat * cos(theta_t) + eta_0 * cos(ti_rad));
    Gamma_h = (eta_mat * cos(ti_rad) - eta_0 * cos(theta_t)) / (eta_mat * cos(ti_rad) + eta_0 * cos(theta_t));
    A_sim = gen_A(deg2rad(180 - ti_deg));
    
    for j = 1:length(sigma_vec1)
        sigma_h = sigma_vec1(j);
        rho = exp(-0.5 * (4 * pi * sigma_h * cos(ti_rad) / lambda)^2);
        L_k = 20 * log10(rho); 
        
        Pvv_s = G_sys - FSPL_s_dB + 20*log10(abs(Gamma_v)) + L_k;
        Phh_s = G_sys - FSPL_s_dB + 20*log10(abs(Gamma_h)) + L_k;
        Pvh_s = Pvv_s - XPD_dB;
        Phv_s = Phh_s - XPD_dB;
        
        Psi_sim = [sqrt(10^((Pvv_s-30)/10)), sqrt(10^((Pvh_s-30)/10)); ...
                   sqrt(10^((Phv_s-30)/10)), sqrt(10^((Phh_s-30)/10))];
                   
        H_sim = H_LoS + kron(Psi_sim, A_sim);
        s_val = svd(H_sim);
        s_val = s_val(1:4); 
        gains = (s_val.^2) / Pn_W;
        
        [P_alloc, ~] = apply_waterfilling(gains, Pt_W);
        P_alloc_M1(:, i, j) = P_alloc;
    end
end

%% ========================================================================
%% MODELO 2 (Basado en Waterfilling2.m)
%% ========================================================================
P_r_LoS = -2.4; d0 = 1.0;
HPBW_E = 50 * (pi / 180); HPBW_A = 50 * (pi / 180);
er = 6.0 - 0.15j;

s_vec_mm2 = linspace(0, 10, 100);
s_vec2 = s_vec_mm2 * 1e-3;
s1 = 2.1739e-3; L1 = 2.6113e-3;
s2 = 7.4607e-3; L2 = 4.3035e-3;
m_L = (L2 - L1) / (s2 - s1);
b_L = L1 - m_L * s1;
L_vec2 = m_L * s_vec2 + b_L; 

P_alloc_M2 = zeros(4, num_angulos, length(s_vec2));

for i = 1:num_angulos
    ti_rad = deg2rad(theta_i_list(i));
    d_t = 0.5 / sin(ti_rad); d_r = d_t;               
    A_ill = (pi * (d_t * tan(HPBW_E/2)) * (d_t * tan(HPBW_A/2))) / cos(ti_rad);
    
    cos_ti = cos(ti_rad); sin_ti = sin(ti_rad);
    sqrt_term = sqrt(er - sin_ti^2); kz = k_wave * cos_ti;
    R_vv = (er * cos_ti - sqrt_term) / (er * cos_ti + sqrt_term);
    R_hh = (cos_ti - sqrt_term) / (cos_ti + sqrt_term);
    
    A_sim = gen_A(deg2rad(180 - theta_i_list(i)));
    
    for j = 1:length(s_vec2)
        s = s_vec2(j); L = L_vec2(j); ks = k_wave * s; 
        
        if ks < 2.0
            f_vv = (2 * R_vv) / (cos_ti + cos_ti);
            termino_1_vv = (2 * sin_ti^2 * (1 + R_vv)^2) / cos_ti;
            suma_F_vv = termino_1_vv * (1 - (1/er)) * ((er - sin_ti^2 - er * cos_ti^2) / (er * cos_ti + sqrt_term));
            
            f_hh = -(2 * R_hh) / (cos_ti + cos_ti);
            termino_1_hh = -(2 * sin_ti^2 * (1 + R_hh)^2) / cos_ti;
            suma_F_hh = termino_1_hh * (er - 1) * ((er - sin_ti^2 - cos_ti^2) / (cos_ti + sqrt_term));
            
            suma_iem_vv = 0; suma_iem_hh = 0;
            for n_idx = 1:20
                W_n = (L^2) / (2 * n_idx); 
                I_vv_n = ((2 * kz)^n_idx) * f_vv + 0.5 * (kz^n_idx) * suma_F_vv; 
                suma_iem_vv = suma_iem_vv + (((s^(2*n_idx)) / factorial(n_idx)) * abs(I_vv_n)^2 * W_n);
                I_hh_n = ((2 * kz)^n_idx) * f_hh + 0.5 * (kz^n_idx) * suma_F_hh; 
                suma_iem_hh = suma_iem_hh + (((s^(2*n_idx)) / factorial(n_idx)) * abs(I_hh_n)^2 * W_n);
            end
            sigma0_vv = (k_wave^2 / 2) * exp(-2 * s^2 * kz^2) * suma_iem_vv;
            sigma0_hh = (k_wave^2 / 2) * exp(-2 * s^2 * kz^2) * suma_iem_hh;
        else
            m_rms = (sqrt(2) * s) / L; 
            sigma0_vv = (abs(R_vv)^2) / (2 * m_rms^2);
            sigma0_hh = (abs(R_hh)^2) / (2 * m_rms^2);
        end
        
        termino_distancia = 10 * log10( (d0^2) / (4 * pi * (d_t^2) * (d_r^2)) );
        termino_area      = 10 * log10(A_ill);
        
        P_scat_vv_dBm = P_r_LoS + termino_distancia + 10 * log10(sigma0_vv) + termino_area;
        P_scat_hh_dBm = P_r_LoS + termino_distancia + 10 * log10(sigma0_hh) + termino_area;
        P_scat_vh_dBm = P_scat_vv_dBm - XPD_dB;
        P_scat_hv_dBm = P_scat_hh_dBm - XPD_dB;

        Psi_sim = [sqrt(10^((P_scat_vv_dBm-30)/10)), sqrt(10^((P_scat_vh_dBm-30)/10)); ...
                   sqrt(10^((P_scat_hv_dBm-30)/10)), sqrt(10^((P_scat_hh_dBm-30)/10))];
        
        H_sim = H_LoS + kron(Psi_sim, A_sim);
        s_val = svd(H_sim);
        s_val = s_val(1:4); 
        gains = (s_val.^2) / Pn_W; 
        
        [P_alloc, ~] = apply_waterfilling(gains, Pt_W);
        P_alloc_M2(:, i, j) = P_alloc;
    end
end

%% ========================================================================
%% VISUALIZACIÓN
%% ========================================================================
fprintf('Generando visualización...\n');
figure('Name', 'Asignación de Potencia - Comparativa de Modelos', 'Color', 'w', 'Position', [50 50 1200 900]);
tiledlayout(3, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

c1 = [0.18, 0.45, 0.77]; % Azul (Flujo 1)
c2 = [0.85, 0.40, 0.28]; % Naranja/Coral (Flujo 2)
c3 = [0.93, 0.73, 0.35]; % Amarillo/Dorado (Flujo 3)
c4 = [0.60, 0.40, 0.65]; % Púrpura (Flujo 4)

orden_indices = [3, 2, 1]; % Índices para 60°, 45°, 30°

for idx_plot = 1:3
    i = orden_indices(idx_plot);
    ang = theta_i_list(i);
    
    % --- Modelo 1 ---
    P_m1_f1 = (squeeze(P_alloc_M1(1, i, :)) / Pt_W) * 100;
    P_m1_f2 = (squeeze(P_alloc_M1(2, i, :)) / Pt_W) * 100;
    P_m1_f3 = (squeeze(P_alloc_M1(3, i, :)) / Pt_W) * 100;
    P_m1_f4 = (squeeze(P_alloc_M1(4, i, :)) / Pt_W) * 100;
    
    nexttile; hold on; grid on;
    plot(sigma_vec1 * 1000, P_m1_f1, 'Color', c1, 'LineWidth', 3);
    plot(sigma_vec1 * 1000, P_m1_f2, 'Color', c2, 'LineWidth', 3);
    plot(sigma_vec1 * 1000, P_m1_f3, 'Color', c3, 'LineWidth', 3);
    plot(sigma_vec1 * 1000, P_m1_f4, 'Color', c4, 'LineWidth', 3);
    
    xline(2.025, 'k:', 'Grava Fina', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off', 'FontSize', 10);
    xline(4.609, 'k:', 'Grava Gruesa', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off', 'FontSize', 10);
    
    ylim([0, 105]); xlim([0, 10]);
    if idx_plot == 1
        title(sprintf('Modelo 1 - \\theta_i = %d^\\circ', ang), 'Interpreter', 'tex');
    else
        title(sprintf('\\theta_i = %d^\\circ', ang), 'Interpreter', 'tex');
    end
    ylabel('Pot. Asignada (%)');
    if idx_plot == 3, xlabel('Rugosidad RMS \sigma_h (mm)', 'Interpreter', 'tex'); end
    set(gca, 'TickLabelInterpreter', 'tex');
    
    % --- Modelo 2 ---
    P_m2_f1 = (squeeze(P_alloc_M2(1, i, :)) / Pt_W) * 100;
    P_m2_f2 = (squeeze(P_alloc_M2(2, i, :)) / Pt_W) * 100;
    P_m2_f3 = (squeeze(P_alloc_M2(3, i, :)) / Pt_W) * 100;
    P_m2_f4 = (squeeze(P_alloc_M2(4, i, :)) / Pt_W) * 100;
    
    nexttile; hold on; grid on;
    plot(s_vec_mm2, P_m2_f1, 'Color', c1, 'LineWidth', 3);
    plot(s_vec_mm2, P_m2_f2, 'Color', c2, 'LineWidth', 3);
    plot(s_vec_mm2, P_m2_f3, 'Color', c3, 'LineWidth', 3);
    plot(s_vec_mm2, P_m2_f4, 'Color', c4, 'LineWidth', 3);
    
    xline(2.025, 'k:', 'Grava Fina', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off', 'FontSize', 10);
    xline(4.609, 'k:', 'Grava Gruesa', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off', 'FontSize', 10);
    
    ylim([0, 105]); xlim([0, 10]);
    if idx_plot == 1
        title(sprintf('Modelo 2 - \\theta_i = %d^\\circ', ang), 'Interpreter', 'tex');
    else
        title(sprintf('\\theta_i = %d^\\circ', ang), 'Interpreter', 'tex');
    end
    ylabel('Pot. Asignada (%)');
    if idx_plot == 3, xlabel('Rugosidad RMS \sigma_h (mm)', 'Interpreter', 'tex'); end
    set(gca, 'TickLabelInterpreter', 'tex');
end

% -------- LEYENDAS GLOBALES --------
h1 = plot(NaN, NaN, 'Color', c1, 'LineWidth', 4);
h2 = plot(NaN, NaN, 'Color', c2, 'LineWidth', 4);
h3 = plot(NaN, NaN, 'Color', c3, 'LineWidth', 4);
h4 = plot(NaN, NaN, 'Color', c4, 'LineWidth', 4);
lg1 = legend([h1, h2, h3, h4], {'Flujo 1', 'Flujo 2', 'Flujo 3', 'Flujo 4'}, 'Orientation', 'horizontal', 'FontSize', 11);
lg1.Layout.Tile = 'south';

%% FUNCIONES
function [P_alloc, Capacity] = apply_waterfilling(gains, P_tot)
    [g_sorted, idx] = sort(gains, 'descend');
    N_streams = length(g_sorted);
    k = N_streams; 
    while k > 0
        inv_gains = 1 ./ g_sorted(1:k);
        mu = (P_tot + sum(inv_gains)) / k;
        if (mu - 1/g_sorted(k)) > 0, break; end
        k = k - 1; 
    end
    P_alloc_sorted = zeros(N_streams, 1);
    for idx_i = 1:k, P_alloc_sorted(idx_i) = mu - 1/g_sorted(idx_i); end
    P_alloc = zeros(N_streams, 1);
    P_alloc(idx) = P_alloc_sorted;
    Capacity = sum(log2(1 + P_alloc .* gains));
end
