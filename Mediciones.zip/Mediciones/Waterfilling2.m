%========================================================================
% SIMULACIÓN AVANZADA MIMO ESPACIAL Y BIESTÁTICA
% Canal: H = H_LoS + (Psi_sim kron A_sim)
% Física: IEM/GO + L(s) Dinámico + XPD
% Optimización: Waterfilling sobre 4 Flujos Espaciales
%========================================================================

clc; clear; close all;

%% 1. PARÁMETROS DEL SISTEMA, RF Y ANTENAS
f = 28e9;               
c = 3e8;                
lambda = c / f;         
k = 2 * pi / lambda;    

P_t_dBm = 9;                  
Pt_W = 10^((P_t_dBm - 30)/10); 
NF = -38.7;                   
Pn_W = 10^((NF - 30)/10);     
XPD_dB = 30;

% Calibración Teórica y Geometría del Radar
P_r_LoS = -2.4;         
d0  = 1.0;              
HPBW_E = 50 * (pi / 180); 
HPBW_A = 50 * (pi / 180);

%% 2. MODELO ESPACIAL BASE (LoS) Y FIRMAS DE FASE
N = 4; % Número de elementos de antena
m = (0:N-1)'; 
% Función generadora de la matriz espacial de fase
gen_A = @(th) (exp(-1j * pi * cos(th) * m)) * (exp(-1j * pi * cos(th) * m))';

% Construcción empírica del canal Línea de Vista (LoS)
dBm_vv = -2.63; dBm_vh = -32.03; dBm_hv = -20.61; dBm_hh = -2.09;
Psi_Los = sqrt((10.^([dBm_vv, dBm_vh; dBm_hv, dBm_hh] / 10)) / 1000);
A_LoS = gen_A(deg2rad(90));
H_LoS = kron(Psi_Los, A_LoS); % Matriz Base 8x8

%% 3. CONFIGURACIÓN DEL BARRIDO PARAMÉTRICO Y GEOMORFOLOGÍA
er = 6.0 - 0.15j;       

s_vec_mm = linspace(0.5, 10, 100);
s_vec = s_vec_mm * 1e-3;
num_s = length(s_vec);

s1 = 2.1739e-3; L1 = 2.6113e-3;
s2 = 7.4607e-3; L2 = 4.3035e-3;
m_L = (L2 - L1) / (s2 - s1);
b_L = L1 - m_L * s1;
L_vec = m_L * s_vec + b_L; 

theta_i_list = [30, 45, 60];
num_angulos = length(theta_i_list);

% Contenedores (Ahora almacenamos 4 flujos espaciales)
P_alloc_W = zeros(4, num_angulos, num_s); 
Cap_WF    = zeros(num_angulos, num_s);
Cap_Eq    = zeros(num_angulos, num_s);

fprintf('Iniciando cálculo H = H_0 + H_s y optimizando 4 flujos...\n');

%% 4. MOTOR DE CÁLCULO FÍSICO Y MATRICIAL
for i = 1:num_angulos
    ti_rad = deg2rad(theta_i_list(i));
    
    d_t = 0.5 / sin(ti_rad); d_r = d_t;               
    A_ill = (pi * (d_t * tan(HPBW_E/2)) * (d_t * tan(HPBW_A/2))) / cos(ti_rad);
    
    cos_ti = cos(ti_rad); sin_ti = sin(ti_rad);
    sqrt_term = sqrt(er - sin_ti^2); kz = k * cos_ti;
    R_vv = (er * cos_ti - sqrt_term) / (er * cos_ti + sqrt_term);
    R_hh = (cos_ti - sqrt_term) / (cos_ti + sqrt_term);
    
    % Firma espacial de la componente dispersada
    A_sim = gen_A(deg2rad(180 - theta_i_list(i)));
    
    for j = 1:num_s
        s = s_vec(j); L = L_vec(j); ks = k * s; 
        
        % FÍSICA IEM/GO (Extracto de potencia)
        if ks < 2.0
            f_vv = (2 * R_vv) / (cos_ti + cos_ti);
            termino_1_vv = (2 * sin_ti^2 * (1 + R_vv)^2) / cos_ti;
            suma_F_vv = termino_1_vv * (1 - (1/er)) * ((er - sin_ti^2 - er * cos_ti^2) / (er * cos_ti + sqrt_term));
            
            f_hh = -(2 * R_hh) / (cos_ti + cos_ti);
            termino_1_hh = -(2 * sin_ti^2 * (1 + R_hh)^2) / cos_ti;
            suma_F_hh = termino_1_hh * (er - 1) * ((er - sin_ti^2 - cos_ti^2) / (cos_ti + sqrt_term));
            
            suma_iem_vv = 0; suma_iem_hh = 0;
            for n = 1:20
                W_n = (L^2) / (2 * n); 
                I_vv_n = ((2 * kz)^n) * f_vv + 0.5 * (kz^n) * suma_F_vv; 
                suma_iem_vv = suma_iem_vv + (((s^(2*n)) / factorial(n)) * abs(I_vv_n)^2 * W_n);
                I_hh_n = ((2 * kz)^n) * f_hh + 0.5 * (kz^n) * suma_F_hh; 
                suma_iem_hh = suma_iem_hh + (((s^(2*n)) / factorial(n)) * abs(I_hh_n)^2 * W_n);
            end
            sigma0_vv = (k^2 / 2) * exp(-2 * s^2 * kz^2) * suma_iem_vv;
            sigma0_hh = (k^2 / 2) * exp(-2 * s^2 * kz^2) * suma_iem_hh;
        else
            m_rms = (sqrt(2) * s) / L; 
            sigma0_vv = (abs(R_vv)^2) / (2 * m_rms^2);
            sigma0_hh = (abs(R_hh)^2) / (2 * m_rms^2);
        end
        
        % CALIBRACIÓN Y DISCRIMINACIÓN CRUZADA
        termino_distancia = 10 * log10( (d0^2) / (4 * pi * (d_t^2) * (d_r^2)) );
        termino_area      = 10 * log10(A_ill);
        
        P_scat_vv_dBm = P_r_LoS + termino_distancia + 10 * log10(sigma0_vv) + termino_area;
        P_scat_hh_dBm = P_r_LoS + termino_distancia + 10 * log10(sigma0_hh) + termino_area;
        P_scat_vh_dBm = P_scat_vv_dBm - XPD_dB;
        P_scat_hv_dBm = P_scat_hh_dBm - XPD_dB;

        % --- CONSTRUCCIÓN DE LA MATRIZ TOTAL DEL CANAL H ---
        % Convertimos las potencias simuladas a amplitud lineal para Psi
        Psi_sim = [sqrt(10^((P_scat_vv_dBm-30)/10)), sqrt(10^((P_scat_vh_dBm-30)/10)); ...
                   sqrt(10^((P_scat_hv_dBm-30)/10)), sqrt(10^((P_scat_hh_dBm-30)/10))];
        
        % Fusión de la Matriz LoS y la Dispersada (Kron)
        H_sim = H_LoS + kron(Psi_sim, A_sim);
        
        % SVD y Extracción de las 4 mejores ganancias
        s_val = svd(H_sim);
        s_val = s_val(1:4); 
        gains = (s_val.^2) / Pn_W; 
        
        % --- OPTIMIZACIÓN WATERFILLING ---
        [P_alloc, C_wf] = apply_waterfilling(gains, Pt_W);
        P_alloc_W(:, i, j) = P_alloc; % Guardamos los 4 flujos
        Cap_WF(i, j) = C_wf;
        Cap_Eq(i, j) = sum(log2(1 + (Pt_W/4) .* gains)); % Repartido en 4
    end
end

fprintf('Generando visualización idéntica al reporte...\n');

%% 5. VISUALIZACIÓN REPLICADA (POTENCIA EN PORCENTAJE)
figure('Name', 'Optimización por Waterfilling (Distribución Porcentual)', 'Color', 'w', 'Position', [50 50 1200 900]);
tiledlayout(3, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

% Colores extraídos de tu imagen
c1 = [0.18, 0.45, 0.77]; % Azul (Flujo 1)
c2 = [0.85, 0.40, 0.28]; % Naranja/Coral (Flujo 2)
c3 = [0.93, 0.73, 0.35]; % Amarillo/Dorado (Flujo 3)
c4 = [0.60, 0.40, 0.65]; % Púrpura (Flujo 4)
c_cap_wf = [0.40, 0.50, 0.95]; % Azul capacidad
c_cap_eq = [1.00, 0.40, 0.40]; % Rojo capacidad

orden_indices = [3, 2, 1]; 

for idx = 1:3
    i = orden_indices(idx);
    ang = theta_i_list(i);
    
    % Extraer los 4 flujos y convertirlos a PORCENTAJE respecto a Pt_W
    P_f1_pct = (squeeze(P_alloc_W(1, i, :)) / Pt_W) * 100;
    P_f2_pct = (squeeze(P_alloc_W(2, i, :)) / Pt_W) * 100;
    P_f3_pct = (squeeze(P_alloc_W(3, i, :)) / Pt_W) * 100;
    P_f4_pct = (squeeze(P_alloc_W(4, i, :)) / Pt_W) * 100;
    
    % -------- COLUMNA 1: Potencia Asignada (%) --------
    nexttile; hold on; grid on;
    plot(s_vec_mm, P_f1_pct, 'Color', c1, 'LineWidth', 3);
    plot(s_vec_mm, P_f2_pct, 'Color', c2, 'LineWidth', 3);
    plot(s_vec_mm, P_f3_pct, 'Color', c3, 'LineWidth', 3);
    plot(s_vec_mm, P_f4_pct, 'Color', c4, 'LineWidth', 3);
    
    xline(2.025, 'k:', 'Grava Fina', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off', 'FontSize', 10);
    xline(4.609, 'k:', 'Grava Gruesa', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off', 'FontSize', 10);
    
    ylim([0, 105]); % Escala fija de 0% a 105% (para dar respiro superior)
    xlim([0, 10]);
    title(sprintf('Distribución de Potencia - \\theta_i = %d^\\circ', ang), 'Interpreter', 'tex');
    ylabel('Pot. Asignada (%)');
    if idx == 3, xlabel('Rugosidad RMS \sigma_h (mm)', 'Interpreter', 'tex'); end
    set(gca, 'TickLabelInterpreter', 'tex');
    
    % -------- COLUMNA 2: Capacidad del Canal --------
    nexttile; hold on; grid on;
    plot(s_vec_mm, Cap_WF(i, :), 'Color', c_cap_wf, 'LineWidth', 3.5);
    plot(s_vec_mm, Cap_Eq(i, :), 'Color', c_cap_eq, 'LineStyle', '--', 'LineWidth', 3.5);
    
    xline(2.025, 'k:', 'Grava Fina', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off', 'FontSize', 10);
    xline(4.609, 'k:', 'Grava Gruesa', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off', 'FontSize', 10);
    
    ylim([floor(min(Cap_Eq(i,:)))-1, ceil(max(Cap_WF(i,:)))+1]); xlim([0, 10]);
    title(sprintf('Capacidad del Canal - \\theta_i = %d^\\circ', ang), 'Interpreter', 'tex');
    ylabel('Capacidad (bits/s/Hz)');
    if idx == 3, xlabel('Rugosidad RMS \sigma_h (mm)', 'Interpreter', 'tex'); end
    set(gca, 'TickLabelInterpreter', 'tex');
end

% -------- LEYENDAS GLOBALES --------
h1 = plot(NaN, NaN, 'Color', c1, 'LineWidth', 4);
h2 = plot(NaN, NaN, 'Color', c2, 'LineWidth', 4);
h3 = plot(NaN, NaN, 'Color', c3, 'LineWidth', 4);
h4 = plot(NaN, NaN, 'Color', c4, 'LineWidth', 4);
lg1 = legend([h1, h2, h3, h4], {'Flujo 1', 'Flujo 2', 'Flujo 3', 'Flujo 4'}, 'Orientation', 'horizontal', 'FontSize', 11);
lg1.Layout.Tile = 'south';

%% 6. LIBRERÍA DE OPTIMIZACIÓN
function [P_alloc, Capacity] = apply_waterfilling(gains, P_tot)
    [g_sorted, idx] = sort(gains, 'descend');
    N_streams = length(g_sorted);
    k = N_streams; 
    while k > 0
        inv_gains = 1 ./ g_sorted(1:k);
        mu = (P_tot + sum(inv_gains)) / k;
        if (mu - 1/g_sorted(k)) > 0, break; end
        k = k - 1; 
    end
    P_alloc_sorted = zeros(N_streams, 1);
    for i = 1:k, P_alloc_sorted(i) = mu - 1/g_sorted(i); end
    P_alloc = zeros(N_streams, 1);
    P_alloc(idx) = P_alloc_sorted;
    Capacity = sum(log2(1 + P_alloc .* gains));
end
