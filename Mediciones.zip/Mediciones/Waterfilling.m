% Waterfilling

clc; clear; close all;

%% Parámetros Globales y de RF
f = 28e9; c = 3e8; lambda = c / f;
N = 4;
P_t_dBm = 9;                  % Potencia de transmisión
Pt_W = 10^((P_t_dBm - 30)/10); % Potencia en Watts
NF = -38.7;                   % Piso de ruido
Pn_W = 10^((NF - 30)/10);     % Ruido en Watts
XPD_dB = 30;

% Calibración Teórica 
G_sys = 53.25;

%% Configuración de Materiales y Ángulos
eta_0 = 377; 
eta_mat = 153.9 + 1.92i; 
theta_t = 0;

theta_i_list = [60, 45, 30]; % Ángulos de incidencia a evaluar
sigma_vec = linspace(0, 10e-3, 100); % Barrido de rugosidad de 0 a 10 mm

%% Matriz LoS Base
dBm_vv = -2.63; dBm_vh = -32.03; dBm_hv = -20.61; dBm_hh = -2.09;
Psi_Los = sqrt((10.^([dBm_vv, dBm_vh; dBm_hv, dBm_hh] / 10)) / 1000);
m = (0:N-1)'; 
gen_A = @(th) (exp(-1j * pi * cos(th) * m)) * (exp(-1j * pi * cos(th) * m))';
A_LoS = gen_A(deg2rad(90));
H_LoS = kron(Psi_Los, A_LoS);

%% Contenedores de Resultados
% Celdas para guardar los resultados de cada ángulo
P_asignada_all = cell(3,1);
Cap_WF_all = cell(3,1);
Cap_Eq_all = cell(3,1);

%% Bucle Principal por Ángulo
for ang_idx = 1:3
    theta_i_deg = theta_i_list(ang_idx);
    th_i = deg2rad(theta_i_deg);
    alpha_deg = 90 - theta_i_deg;
    d_s = 2 * (0.5 / cosd(alpha_deg));
    FSPL_s_dB = 20 * log10((4 * pi * d_s) / lambda);

    % Coeficientes de Fresnel 
    Gamma_v = (eta_mat * cos(theta_t) - eta_0 * cos(th_i)) / (eta_mat * cos(theta_t) + eta_0 * cos(th_i));
    Gamma_h = (eta_mat * cos(th_i) - eta_0 * cos(theta_t)) / (eta_mat * cos(th_i) + eta_0 * cos(theta_t));
    A_sim = gen_A(deg2rad(180 - theta_i_deg));
    
    % Variables temporales para el barrido
    P_asig_temp = zeros(4, length(sigma_vec));
    Cap_WF_temp = zeros(1, length(sigma_vec));
    Cap_Eq_temp = zeros(1, length(sigma_vec));
    
    for k = 1:length(sigma_vec)
        sigma_h = sigma_vec(k);
        
        rho = exp(-0.5 * (4 * pi * sigma_h * cos(th_i) / lambda)^2);
        L_k = 20 * log10(rho); 
        
        Pvv_s = G_sys - FSPL_s_dB + 20*log10(abs(Gamma_v)) + L_k;
        Phh_s = G_sys - FSPL_s_dB + 20*log10(abs(Gamma_h)) + L_k;
        Pvh_s = Pvv_s - XPD_dB;
        Phv_s = Phh_s - XPD_dB;
        
        Psi_sim = [sqrt(10^((Pvv_s-30)/10)), sqrt(10^((Pvh_s-30)/10)); ...
                   sqrt(10^((Phv_s-30)/10)), sqrt(10^((Phh_s-30)/10))];
                   
        H_sim = H_LoS + kron(Psi_sim, A_sim);
        s_val = svd(H_sim);
        s_val = s_val(1:4); 
        
        gains = (s_val.^2) / Pn_W;
        
        % Waterfilling
        [P_alloc, C_wf] = apply_waterfilling(gains, Pt_W);
        P_asig_temp(:, k) = P_alloc;
        Cap_WF_temp(k) = C_wf;
        
        % Asignación Equitativa
        P_equal = (Pt_W / 4) * ones(4,1);
        Cap_Eq_temp(k) = sum(log2(1 + P_equal .* gains));
    end
    
    P_asignada_all{ang_idx} = P_asig_temp;
    Cap_WF_all{ang_idx} = Cap_WF_temp;
    Cap_Eq_all{ang_idx} = Cap_Eq_temp;
end

%% Visualización 3x2 (Fracciones de Potencia en Porcentaje)
figure('Name', 'Optimización por Waterfilling (3 Escenarios)', 'Color', 'w', 'Position', [50 50 1200 800]);
tiledlayout(3, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

% Colores
c1 = [0, 0.4470, 0.7410]; c2 = [0.8500, 0.3250, 0.0980]; 
c3 = [0.9290, 0.6940, 0.1250]; c4 = [0.4940, 0.1840, 0.5560]; 
cwf = [0, 0, 1]; ceq = [1, 0, 0]; 
alpha_val = 0.6; % Transparencia

x_patch = [sigma_vec * 1000, NaN];

for r = 1:3
    P_asig = P_asignada_all{r};
    C_wF = Cap_WF_all{r};
    C_eq = Cap_Eq_all{r};
    
    % --- NUEVO: Calcular las fracciones en porcentaje (%) ---
    % Dividimos la potencia en Watts de cada flujo entre la potencia total Pt_W y multiplicamos por 100
    P_porcentaje = (P_asig / Pt_W) * 100;
    
    % --- Columna 1: Asignación de Potencia (PORCENTAJE) ---
    nexttile; hold on; grid on;
    patch(x_patch, [P_porcentaje(1,:), NaN], c1, 'EdgeColor', c1, 'EdgeAlpha', alpha_val, 'FaceColor', 'none', 'LineWidth', 2.5);
    patch(x_patch, [P_porcentaje(2,:), NaN], c2, 'EdgeColor', c2, 'EdgeAlpha', alpha_val, 'FaceColor', 'none', 'LineWidth', 2.5);
    patch(x_patch, [P_porcentaje(3,:), NaN], c3, 'EdgeColor', c3, 'EdgeAlpha', alpha_val, 'FaceColor', 'none', 'LineWidth', 2.5);
    patch(x_patch, [P_porcentaje(4,:), NaN], c4, 'EdgeColor', c4, 'EdgeAlpha', alpha_val, 'FaceColor', 'none', 'LineWidth', 2.5);
    
    % Líneas marcadoras de las superficies físicas
    xline(2.025, 'k:', 'Grava Fina', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
    xline(4.609, 'k:', 'Grava Gruesa', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
    
    ylim([-5, 105]); xlim([0, 10]); % Límites de 0% a 100% con un pequeño margen
    title(sprintf('Distribución de Potencia - \\theta_i = %d^\\circ', theta_i_list(r)), 'Interpreter', 'tex');
    ylabel('Potencia Asignada (%)', 'Interpreter', 'tex');
    set(gca, 'TickLabelInterpreter', 'latex');
    if r == 3
        xlabel('Rugosidad RMS $\sigma_h$ (mm)', 'Interpreter', 'latex');
    end
    
    % --- Columna 2: Capacidad ---
    nexttile; hold on; grid on;
    patch(x_patch, [C_wF, NaN], cwf, 'EdgeColor', cwf, 'EdgeAlpha', alpha_val, 'FaceColor', 'none', 'LineWidth', 2.5);
    patch(x_patch, [C_eq, NaN], ceq, 'EdgeColor', ceq, 'EdgeAlpha', alpha_val, 'FaceColor', 'none', 'LineWidth', 2.5, 'LineStyle', '--');
    
    xline(2.025, 'k:', 'Grava Fina', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
    xline(4.609, 'k:', 'Grava Gruesa', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
    
    ylim([max(0, min(C_eq)-1), max(C_wF)+1]); xlim([0, 10]);
    title(sprintf('Capacidad del Canal - \\theta_i = %d^\\circ', theta_i_list(r)), 'Interpreter', 'tex');
    ylabel('Capacidad (bits/s/Hz)', 'Interpreter', 'latex');
    set(gca, 'TickLabelInterpreter', 'latex');
    if r == 3
        xlabel('Rugosidad RMS $\sigma_h$ (mm)', 'Interpreter', 'latex');
    end
end

% Leyendas Globales modificadas para incluir las curvas de capacidad
h1 = plot(NaN, NaN, 'Color', c1, 'LineWidth', 2.5);
h2 = plot(NaN, NaN, 'Color', c2, 'LineWidth', 2.5);
h3 = plot(NaN, NaN, 'Color', c3, 'LineWidth', 2.5);
h4 = plot(NaN, NaN, 'Color', c4, 'LineWidth', 2.5);
hwf_line = plot(NaN, NaN, 'Color', cwf, 'LineWidth', 2.5);
heq_line = plot(NaN, NaN, 'Color', ceq, 'LineWidth', 2.5, 'LineStyle', '--');

lg1 = legend([h1, h2, h3, h4, hwf_line, heq_line], ...
    {'\text{Flujo 1}', '\text{Flujo 2}', '\text{Flujo 3}', '\text{Flujo 4}', ...
     '\text{Capacidad WF}', '\text{Capacidad Equitativa}'}, ...
    'Orientation', 'horizontal', 'Interpreter', 'latex');
lg1.Layout.Tile = 'south';


%% FUNCIÓN DE WATERFILLING
function [P_alloc, Capacity] = apply_waterfilling(gains, P_tot)
    [g_sorted, idx] = sort(gains, 'descend');
    N_streams = length(g_sorted);
    
    k = N_streams; 
    while k > 0
        inv_gains = 1 ./ g_sorted(1:k);
        mu = (P_tot + sum(inv_gains)) / k;
        
        if (mu - 1/g_sorted(k)) > 0
            break; 
        end
        k = k - 1; 
    end
    
    P_alloc_sorted = zeros(N_streams, 1);
    for i = 1:k
        P_alloc_sorted(i) = mu - 1/g_sorted(i);
    end
    
    P_alloc = zeros(N_streams, 1);
    P_alloc(idx) = P_alloc_sorted;
    
    Capacity = sum(log2(1 + P_alloc .* gains));
end
